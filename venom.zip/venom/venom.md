⠀ _   _____  ____  ____  ____ ___ 
| | / / _ \/ __ \/ __ \/ __ `__ \
| |/ /  __/ / / / /_/ / / / / / /
|___/\___/_/ /_/\____/_/ /_/ /_/ 
venom version 1.0 & 1.2


[=====Venom v1.0=====]


# Key Features:

- Local Copy:
- Creates a copy of the executable file in a randomly selected local directory.
- Endless Loop: Continuously creates new directories and copies.

- Important Functions:
- get_random_directory():
- Randomly selects the target directory from /tmp, /var/tmp, or the user's home directory.
- The copy creation process includes reading the original file and writing the copy file at the target location.


[=====Venom v1.2=====]


# ey Features:

- Chain Deployment:
- Create and run a local copy using a child process (fork).
- Network Deployment:
- Use SCP and SSH to copy and run executable files on other network devices.

- Explanation:
- Venom that has only been compiled is Venom version 1.0
